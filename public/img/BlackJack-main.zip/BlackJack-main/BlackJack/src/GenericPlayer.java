import java.util.Scanner;

public abstract class GenericPlayer extends Hand{
	protected String name;
	protected int score;
	protected int wins;
	protected int loses;
	protected int pushes;
	protected boolean isBusted=false;
	
	protected GenericPlayer(String name) {
		super();
		this.name=name;
	}
	
	public abstract boolean isHitting(Scanner s);
	
	public boolean isBusted() {
		return this.isBusted;
	}
	
	public void busted() {
		System.out.printf("%n%n%s Busted!",name);
		isBusted=true;
	}
	
	public String toString() {
		return String.format("%n%s: %s",name, super.toString());
	}
	
	public void restart() {
		for(int i=0; i<cards.size();i++) {
			cards.removeAll(cards);
			isBusted=false;
		}
	}

}
