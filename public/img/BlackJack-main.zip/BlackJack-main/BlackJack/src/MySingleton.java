
public class MySingleton {
	private static MySingleton _instance = null;
	
	private MySingleton() {}
	
	public static MySingleton instance() {
		if(_instance==null) {
			_instance = new MySingleton();
		}
		return _instance;
	}
}
