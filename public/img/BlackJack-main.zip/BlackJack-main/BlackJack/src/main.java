import java.util.ArrayList;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Deck d = new Deck();
		boolean playing = true;
		int gameCount = 1;
		int numPlayers=0;
		
		System.out.printf("%nWelcome to BlackJack!%n%n");
		
			//System.out.printf("How many players?%n");
			
			do {
				System.out.printf("How many players?%n");
				try {
					numPlayers = input.nextInt();
				} catch (java.util.InputMismatchException e) { // if the user enters something that is not an integer
			        System.out.println("Please only enter numbers");
			        input.next();
			    }
			} while (numPlayers == 0);
			
			//int numPlayers = input.nextInt();
			ArrayList<GenericPlayer> players = new ArrayList<>(numPlayers+1);
		
			// Add each player to ArrayList
			for(int i=0; i<numPlayers; i++) {
				System.out.printf("Enter player #%d name:", i+1);
				String name = input.next();
				Player p = new Player(name);
				p.score = 0;
				players.add(p);
			
			}
			House h = new House();
			players.add(h);
			
			while(playing) {
				
			System.out.printf("%nGame %d%n",gameCount);
			for(int i=0; i<numPlayers; i++) {
				GenericPlayer p = players.get(i);
				System.out.printf("%s has %d Wins, %d Loses, and %d Pushes%n",p.name,p.wins,p.loses,p.pushes);
			}
			
			// Deal two cards to every player
			for(int i=0; i<players.size(); i++) {
				GenericPlayer p = players.get(i);
				d.draw(p); //deal card 1
				d.draw(p); //deal card 2
				if(p instanceof House) {
					House house = (House) p;
					house.flipFirstCard();
				}
				System.out.printf("%s", p);
			}
			
			// Do the players want to hit?
			for(int i=0; i<players.size(); i++) {
				GenericPlayer p = players.get(i);
				if(p instanceof House) {
					House house = (House) p;
					house.flipFirstCard();
				}
				
				while(!p.isBusted()) {
					if(p.isHitting(input)) {
						d.draw(p);
						System.out.printf("%s", p);
					} else {
						break;
					}
					//if the player busts
					if(p.getValue()>21) {
						p.busted();
					}
				}
			}
		
			// Display final hands
			System.out.printf("%n%nFinal Hands:%n");
			for(int i=0; i<players.size(); i++) {
				GenericPlayer p = players.get(i);
				System.out.printf("%s", p);
			}
			System.out.printf("%n%n");
		
			// Determine results
			int houseValue = h.getValue();
			for(int i=0; i<players.size(); i++) {
				GenericPlayer p = players.get(i);
				if(p instanceof House) {
					continue;
				}
				//win condition checks
				if(!p.isBusted() && houseValue>21) {
					//player wins
					((Player) p).win();
					p.wins++;
				} else if(p.getValue()==houseValue && !p.isBusted()) {
					//player pushed
					((Player) p).push();
					p.pushes++;
				} else if(!p.isBusted() && p.getValue()>houseValue) {
					//player wins
					((Player) p).win();
					p.wins++;
				} else {
					//player lose
					((Player) p).lose();
					p.loses++;
					
				}
				p.restart();
				h.restart();
				
			}
			System.out.printf("Do you want to keep playing? (y/n)");
			String response = input.next();
			if(response.equals("y")) {
				gameCount++;
			} else if(response.equals("n")) {
				System.exit(0);
			}
		}
	}

}
