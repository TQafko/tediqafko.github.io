# BlackJack
BlackJack with extra credit(Project 4: Continuous Play with Score Keeping)

1. Click BlackJack>src>(default package) and right click main.java
2. Go to run as and select Java Application
3. The game should show up on the console with the text "Welcome to BlackJack!"
4. Enter the number of players
5. It will ask for each player's name
6. Game 1 will start and display the number of wins/loses/pushes of each player which should be 0 in the beggining
7. The cards of the players will be shown as A,1,2,3,4,5,6,7,8,9,10,J,Q,K with a letter next to it s(spades), h(hearts), d(diamonds), c(clubs).
8. The house will show one card only and the goal is to get a higher score than the house that is 21 or less.
9. The game will ask you to hit until you burst(go over a total sum of 21) or you stop hitting.
10. Once all the players have hit, the house will start hitting
11. The final hands will be shown and which player won or lost.
12. The game will ask if you want to keep playing
13. If you enter yes, Game 2 will start and all the wins, the loses, and the pushes will be recorded.
